function toc_function(){
    $('p').css('display', 'block');
}
